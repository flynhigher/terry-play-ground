using System;
using NUnit.Framework;
namespace Bank.Test {
	[TestFixture]
	public class TestAccount {
		private Account _unitUnderTest;
		[SetUp]
		public void SetUp() {
			_unitUnderTest = new Account(100);
		}
		[TearDown]
		public void TearDown() {
			_unitUnderTest = null;
		}
		[Test]
		public void TestConstructorAccount() {
			Account testAccount = new Account(100);
			Assert.IsNotNull(testAccount, "Constructor of type, Account failed to create instance.");
			Assert.AreEqual(100, testAccount.GetBalance(), "Initial amount is not recorded correctly.");
		}
		[Test]
		public void TestWithdraw() {
			Assert.AreEqual(60, _unitUnderTest.Withdraw(60), "Withdraw method returned unexpected amount.");
		}
		[Test]
		[ExpectedException(typeof(ArgumentException))]
		public void TestWithdrawWithException() {
			_unitUnderTest.Withdraw(150);
		}
		[Test]
		public void TestDeposit() {
			_unitUnderTest.Deposit(50);
			Assert.AreEqual(150, _unitUnderTest.GetBalance(), "Deposit method generated unexpected state.");
		}
		[Test]
		public void TestGetBalance() {
			_unitUnderTest.Withdraw(55);
			Assert.AreEqual(45, _unitUnderTest.GetBalance(), "Withdraw method changed Account state unexpectedly.");
			_unitUnderTest.Deposit(50);
			Assert.AreEqual(95, _unitUnderTest.GetBalance(), "Deposit method changed Account state unexpectedly.");
			_unitUnderTest.Withdraw(15);
			Assert.AreEqual(80, _unitUnderTest.GetBalance(), "Withdraw method changed Account state unexpectedly.");
		}
	}
}
