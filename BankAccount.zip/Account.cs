using System;
namespace Bank {
	public class Account {
		private double _amount = 0;
		public Account(double initialAmount) {
			_amount = initialAmount;
		}
		public double Withdraw(double amount) {
			if(_amount < amount)
				throw new ArgumentException("Invalid whthdraw amount", "amount");
			_amount -= amount;
			return amount;
		}
		public void Deposit(double amount) {
			if(amount <= 0)
				throw new ArgumentException("Invalid deposit amount", "amount");
			_amount += amount;
		}
		public double GetBalance() {
			return _amount;
		}
	}
}
