using System;
using System.Data;
using System.Text;
using System.Xml;

namespace AllianceCapital.Aws.ServiceMain.Test {
	public class MockDataReader : IDataReader {
		private XmlNode _data = null;
		private int _index = -1;
		private int _fieldCount = 0;
		private int _recordsAffected = 0;
		private bool _isClosed = false;
		private int _depth = 0;

		public MockDataReader(string dataFilePath) {
			XmlDocument data = new XmlDocument();
			data.Load(dataFilePath);
			Initialize(data);
		}

		public MockDataReader(XmlNode dataXmlNode) {
			Initialize(dataXmlNode);
		}

		private void Initialize(XmlNode dataXmlNode) {
			if (dataXmlNode == null)
				throw new ArgumentNullException("dataXmlNode");
			_data = dataXmlNode;
			if (_data.FirstChild != null) {
				_data = _data.FirstChild;
				_fieldCount = _data.ChildNodes.Count;
			}
			else
				_fieldCount = 1;
		}

		public MockDataReader(XmlNodeList dataXmlNodeList) {
			StringBuilder sb = new StringBuilder("<root>");
			foreach (XmlNode node in dataXmlNodeList) {
				sb.Append(node.OuterXml);
			}
			sb.Append("</root>");
			XmlDocument doc = new XmlDocument();
			doc.LoadXml(sb.ToString());
			Initialize(doc);
		}

		public void Close() {
			throw new NotImplementedException();
		}

		public DataTable GetSchemaTable() {
			throw new NotImplementedException();
		}

		public bool NextResult() {
			throw new NotImplementedException();
		}

		public bool Read() {
			if (++_index >= _fieldCount)
				return false;
			else
				return true;
		}

		public int Depth {
			get { return _depth; }
		}

		public bool IsClosed {
			get { return _isClosed; }
		}

		public int RecordsAffected {
			get { return _recordsAffected; }
		}

		public void Dispose() {
			throw new NotImplementedException();
		}

		public string GetName(int i) {
			throw new NotImplementedException();
		}

		public string GetDataTypeName(int i) {
			throw new NotImplementedException();
		}

		public Type GetFieldType(int i) {
			throw new NotImplementedException();
		}

		public object GetValue(int i) {
			throw new NotImplementedException();
		}

		public int GetValues(object[] values) {
			throw new NotImplementedException();
		}

		public int GetOrdinal(string name) {
			throw new NotImplementedException();
		}

		public bool GetBoolean(int i) {
			throw new NotImplementedException();
		}

		public byte GetByte(int i) {
			throw new NotImplementedException();
		}

		public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length) {
			throw new NotImplementedException();
		}

		public char GetChar(int i) {
			throw new NotImplementedException();
		}

		public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length) {
			throw new NotImplementedException();
		}

		public Guid GetGuid(int i) {
			throw new NotImplementedException();
		}

		public short GetInt16(int i) {
			throw new NotImplementedException();
		}

		public int GetInt32(int i) {
			throw new NotImplementedException();
		}

		public long GetInt64(int i) {
			throw new NotImplementedException();
		}

		public float GetFloat(int i) {
			throw new NotImplementedException();
		}

		public double GetDouble(int i) {
			throw new NotImplementedException();
		}

		public string GetString(int i) {
			throw new NotImplementedException();
		}

		public decimal GetDecimal(int i) {
			throw new NotImplementedException();
		}

		public DateTime GetDateTime(int i) {
			throw new NotImplementedException();
		}

		public IDataReader GetData(int i) {
			throw new NotImplementedException();
		}

		public bool IsDBNull(int i) {
			throw new NotImplementedException();
		}

		public int FieldCount {
			get { return _fieldCount; }
		}

		public object this[int i] {
			get { throw new NotImplementedException(); }
		}

		public object this[string name] {
			get {
				XmlAttribute attribute = _data.ChildNodes.Count > 0
				                         	? _data.ChildNodes[_index].Attributes[name]
				                         	: _data.Attributes[name];
				if (attribute != null)
					return attribute.Value;
				else
					return DBNull.Value;
//					throw new IndexOutOfRangeException(name);
			}
		}
	}
}