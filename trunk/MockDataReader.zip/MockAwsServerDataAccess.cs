using System;
using System.IO;
using System.Xml;
using AllianceCapital.Aws.Api;
using AllianceCapital.Aws.ServerDataAccess;

namespace AllianceCapital.Aws.ServiceMain.Test {
	/// <summary>
	/// Summary description for MockAwsServerDataAccess.
	/// </summary>
	public class MockAwsServerDataAccess : AwsServerDataAccess {
		private XmlDocument _bProcessInfo = new XmlDocument();
		private XmlDocument _taskInfo = new XmlDocument();
		private XmlDocument _taskTarget = new XmlDocument();

		public MockAwsServerDataAccess() {
			_bProcessInfo.Load("bProcessInformation.xml");
			_taskInfo.Load("data_vAppBProcessTasks.xml");
			_taskTarget.Load("data_tasktarget.xml");
		}

		public override string GetOrchestration(string applicationName, string processName) {
			XmlNode processInfoNode =
				_bProcessInfo.SelectSingleNode(
					string.Format("//vApplicationProcesses[@ApplicationName='{0}' and @BProcessName='{1}']", applicationName,
					              processName));
			if (processInfoNode == null)
				throw new Exception(
					string.Format("No BProcessInformation is available for application, {0} and bProcess name, {1}", applicationName,
					              processName));
			return processInfoNode.Attributes["OrchestrationId"].Value;
		}

		public override BProcessInformation GetBProcessInformationByAppNameProcessName(string applicationName,
		                                                                               string processName) {
			XmlNode processInfoNode =
				_bProcessInfo.SelectSingleNode(
					string.Format("//vApplicationProcesses[@ApplicationName='{0}' and @BProcessName='{1}']", applicationName,
					              processName));
			if (processInfoNode == null)
				throw new Exception(
					string.Format("No BProcessInformation is available for application, {0} and bProcess name, {1}", applicationName,
					              processName));
			MockDataReader reader = new MockDataReader(processInfoNode);
			if (reader.Read())
				return BProcessInformation.LoadBProcessInformationFromDataReader(reader);
			else
				return null;
		}

		public override TaskInformation GetTaskInformationByAppNameProcessNameOrchestrationTaskName(string applicationName,
		                                                                                            string processName,
		                                                                                            string
		                                                                                            	orchestrationTaskName) {
			XmlNode taskInfoNode =
				_taskInfo.SelectSingleNode(
					string.Format(
						"//vAppBProcessTasks[@ApplicationName='{0}' and @BProcessName='{1}' and @OrchestrationTaskName='{2}']",
						applicationName, processName, orchestrationTaskName));
			if (taskInfoNode == null)
				throw new Exception(
					string.Format(
						"No TaskInformation is available for application, {0} and bProcess name, {1} and OrchestrationTaskName='{2}'",
						applicationName, processName, orchestrationTaskName));
			MockDataReader reader = new MockDataReader(taskInfoNode);
			if (reader.Read()) {
				TaskInformation taskInfo = TaskInformation.LoadTaskInformationFromDataReader(reader);
				taskInfo.TargetList = GetTargetListByTaskConfigurationGuid(reader["TaskConfigurationGuid"].ToString());
				return taskInfo;
			}
			else
				return null;
		}

		public override TaskInformation GetTaskInformationByAppNameProcessNameTaskName(string applicationName,
		                                                                               string processName, string taskName) {
			XmlNode taskInfoNode =
				_taskInfo.SelectSingleNode(
					string.Format("//vAppBProcessTasks[@ApplicationName='{0}' and @BProcessName='{1}' and @TaskName='{2}']",
					              applicationName, processName, taskName));
			if (taskInfoNode == null)
				throw new Exception(
					string.Format("No TaskInformation is available for application, {0} and bProcess name, {1} and @TaskName='{2}'",
					              applicationName, processName, taskName));
			MockDataReader reader = new MockDataReader(taskInfoNode);
			if (reader.Read()) {
				TaskInformation taskInfo = TaskInformation.LoadTaskInformationFromDataReader(reader);
				taskInfo.TargetList = GetTargetListByTaskConfigurationGuid(reader["TaskConfigurationGuid"].ToString());
				return taskInfo;
			}
			else
				return null;
		}

		public override void ProcessTaskRequest(string xml) {
			using (StreamWriter writer = new StreamWriter("test.xml")) {
				writer.Write(xml);
			}
		}

		private AwsTargetList GetTargetListByTaskConfigurationGuid(string taskConfigurationGuid) {
			XmlNodeList taskTargetNodeList =
				_taskTarget.SelectNodes(
					string.Format("//TaskTarget[@TaskConfigurationGuid='{0}']", taskConfigurationGuid));
			if (taskTargetNodeList == null)
				throw new Exception(
					string.Format("No TaskTarget is available for taskConfigurationGuid, {0}", taskConfigurationGuid));
			MockDataReader reader = new MockDataReader(taskTargetNodeList);
			AwsTargetList targetList = new AwsTargetList();
			while (reader.Read()) {
				AwsTarget target = AwsTarget.LoadAwsTargetConfigurationFromDataReader(reader);
				targetList.Add(target);
			}
			return targetList;
		}
	}
}