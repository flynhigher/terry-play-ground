using System;

namespace AllianceCapital.Aws.AwsException {
	/// <summary>
	/// Summary description for GeneralException.
	/// </summary>
	[Serializable]
	public class AwsServerException : ApplicationException {
		public AwsServerException() : base() {}
		public AwsServerException(String msg, Exception exc) : base(msg, exc) {}
		public AwsServerException(String msg) : base(msg) {}
	}
}