using System;
using System.Data;

namespace AllianceCapital.Aws.ServerDataAccess {
	/// <summary>
	/// BProcess configuration information.
	/// </summary>
	[Serializable]
	public class BProcessInformation {
		private Guid _bProcessGuid;
		private Guid _applicationGuid;
		private string _applicationName;
		private string _orchestrationId;
		private string _bProcessName;
		private Guid _ownerGuid;
		private string _ownerType;
		private Guid _fulfillerGuid;
		private string _fulfillerType;
		private int _expectedInHours;
		private int _deadlineInHours;
		private Guid _iTDSApplicationGuid;

		public Guid BProcessGuid {
			get { return _bProcessGuid; }
		}

		public Guid ApplicationGuid {
			get { return _applicationGuid; }
		}

		public string ApplicationName {
			get { return _applicationName; }
		}

		public string OrchestrationId {
			get { return _orchestrationId; }
		}

		public string BProcessName {
			get { return _bProcessName; }
		}

		public Guid OwnerGuid {
			get { return _ownerGuid; }
		}

		public string OwnerType {
			get { return _ownerType; }
		}

		public Guid FulfillerGuid {
			get { return _fulfillerGuid; }
		}

		public string FulfillerType {
			get { return _fulfillerType; }
		}

		public int ExpectedInHours {
			get { return _expectedInHours; }
		}

		public int DeadlineInHours {
			get { return _deadlineInHours; }
		}

		public Guid ITdsApplicationGuid {
			get { return _iTDSApplicationGuid; }
		}

		public BProcessInformation(Guid bProcessGuid, Guid applicationGuid, string applicationName, string orchestrationId,
		                           string bProcessName, Guid ownerGuid, string ownerType, Guid fulfillerGuid,
		                           string fulfillerType, int expectedInHours, int deadlineInHours, Guid iTDSApplicationGuid) {
			_bProcessGuid = bProcessGuid;
			_applicationGuid = applicationGuid;
			_applicationName = applicationName;
			_orchestrationId = orchestrationId;
			_bProcessName = bProcessName;
			_ownerGuid = ownerGuid;
			_ownerType = ownerType;
			_fulfillerGuid = fulfillerGuid;
			_fulfillerType = fulfillerType;
			_expectedInHours = expectedInHours;
			_deadlineInHours = deadlineInHours;
			_iTDSApplicationGuid = iTDSApplicationGuid;
		}

		public static BProcessInformation LoadBProcessInformationFromDataReader(IDataReader reader) {
			return
				new BProcessInformation(AwsServerDataAccess.GetGuid(AwsServerDataAccess.GetString(reader["BProcessGuid"])),
				                        AwsServerDataAccess.GetGuid(AwsServerDataAccess.GetString(reader["ApplicationGuid"])),
				                        AwsServerDataAccess.GetString(reader["ApplicationName"]),
				                        AwsServerDataAccess.GetString(reader["OrchestrationId"]),
				                        AwsServerDataAccess.GetString(reader["BProcessName"]),
				                        AwsServerDataAccess.GetGuid(AwsServerDataAccess.GetString(reader["OwnerGuid"])),
				                        AwsServerDataAccess.GetString(reader["OwnerType"]),
				                        AwsServerDataAccess.GetGuid(AwsServerDataAccess.GetString(reader["FulfillerGuid"])),
				                        AwsServerDataAccess.GetString(reader["FulfillerType"]),
				                        AwsServerDataAccess.GetInt32(reader["ExpectedInHours"]),
				                        AwsServerDataAccess.GetInt32(reader["DeadlineInHours"]),
				                        AwsServerDataAccess.GetGuid(AwsServerDataAccess.GetString(reader["ITDSApplicationGuid"])));
		}
	}
}