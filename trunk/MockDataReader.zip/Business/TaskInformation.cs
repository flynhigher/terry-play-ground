using System;
using System.Data;
using AllianceCapital.Aws.Api;

namespace AllianceCapital.Aws.ServerDataAccess {
	/// <summary>
	/// Task configuration information.
	/// </summary>
	[Serializable]
	public class TaskInformation {
		private Guid _taskGuid = Guid.Empty;
		private string _taskName = "";
		private string _taskDescription = "";
		private string _orchestrationTaskName = "";
		private AwsTargetList _targetList = new AwsTargetList();
		private string _taskTargetText = "";
		private bool _isTaskEnabled = false;
		private TaskType _taskType;
		private bool _slaStart;
		private int _deadlineInHours;

		public Guid TaskGuid {
			get { return _taskGuid; }
		}

		public string TaskName {
			get { return _taskName; }
		}

		public string OrchestrationTaskName {
			get { return _orchestrationTaskName; }
		}

		public bool IsTaskEnabled {
			get { return _isTaskEnabled; }
		}

		public TaskType TaskType {
			get { return _taskType; }
		}

		public string TaskTargetText {
			get { return _taskTargetText; }
			set { _taskTargetText = value; }
		}

		public bool SlaStart {
			get { return _slaStart; }
		}

		public int DeadlineInHours {
			get { return _deadlineInHours; }
		}

		public AwsTargetList TargetList {
			get { return _targetList; }
			set { _targetList = value; }
		}

		public string TaskDescription {
			get { return _taskDescription; }
		}

		public TaskInformation(Guid taskGuid, string taskName, string taskDescription, string orchestrationTaskName,
		                       string taskTargetText, bool isTaskEnabled, string taskType, bool slaStart, int deadlineInHours) {
			_taskGuid = taskGuid;
			_taskName = taskName;
			_taskDescription = taskDescription;
			_orchestrationTaskName = orchestrationTaskName;
			_taskTargetText = taskTargetText;
			_isTaskEnabled = isTaskEnabled;
			_taskType = (TaskType) Enum.Parse(typeof (TaskType), taskType, true);
			_slaStart = slaStart;
			_deadlineInHours = deadlineInHours;
		}

		public static TaskInformation LoadTaskInformationFromDataReader(IDataReader reader) {
			return
				new TaskInformation(new Guid(AwsServerDataAccess.GetString(reader["TaskGuid"])),
				                    AwsServerDataAccess.GetString(reader["TaskName"]),
				                    AwsServerDataAccess.GetString(reader["TaskDescription"]),
				                    AwsServerDataAccess.GetString(reader["OrchestrationTaskName"]), "",
				                    AwsServerDataAccess.GetBooleanValueFromNumber(reader["TaskEnabled"]),
				                    AwsServerDataAccess.GetString(reader["TaskTypeName"]),
				                    AwsServerDataAccess.GetBooleanValueFromNumber(reader["SlaStart"]),
				                    AwsServerDataAccess.GetInt32(reader["TaskDeadlineInHours"]));
		}
	}
}