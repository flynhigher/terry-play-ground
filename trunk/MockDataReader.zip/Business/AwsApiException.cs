using System;

namespace AllianceCapital.Aws.Api {
	/// <summary>
	/// Summary description for AwsApiException.
	/// </summary>
	public class AwsApiException : ApplicationException {
		public AwsApiException() : base() {}

		public AwsApiException(string msg) : base(msg) {}

		public AwsApiException(string msg, Exception innerEx) : base(msg, innerEx) {}
	}
}