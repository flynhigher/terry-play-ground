using System;

namespace AllianceCapital.Aws.Api {
	[Serializable]
	public enum MessageOperation {
		None,
		Initiate,
		Request,
		Response,
		Assign,
		Reroute,
		Cancel,
		Save,
		Finish,
		Abort,
		WorkItemUpdate,
		Create,
		StartSLA,
		DropOpenTasks
	}
	[Serializable]
	public enum TaskType {
		None,
		Approval,
		Submit,
		Work,
		Assign
	}
}