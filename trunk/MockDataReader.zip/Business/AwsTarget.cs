using System;
using System.Data;
using System.Xml;

namespace AllianceCapital.Aws.Api {
	/// <summary>
	/// Summary description for AwsTarget.
	/// </summary>
	[Serializable]
	public class AwsTarget {
		private bool _isPrimary = false;

		public bool IsPrimary {
			get { return _isPrimary; }
			set { _isPrimary = value; }
		}

		private int _escalationLevel = 0;

		public int EscalationLevel {
			get { return _escalationLevel; }
			set { _escalationLevel = value; }
		}

		private string _name = "";

		public string Name {
			get { return _name; }
			set { _name = value; }
		}

		private TargetType _type = TargetType.None;

		public TargetType Type {
			get { return _type; }
			set { _type = value; }
		}

		private string _resolvedTarget = "";

		public string ResolvedTarget {
			get { return _resolvedTarget; }
			set { _resolvedTarget = value; }
		}

		private TargetType _resolvedTargetType = TargetType.None;

		public TargetType ResolvedTargetType {
			get { return _resolvedTargetType; }
			set { _resolvedTargetType = value; }
		}

		public AwsTarget() {}

		public AwsTarget(string name, TargetType type) {
			_name = name == null ? "" : name;
			_type = type;
		}

		public AwsTarget(string name, TargetType type, bool isPrimary, int escalationLevel) : this(name, type) {
			_isPrimary = isPrimary;
			_escalationLevel = escalationLevel;
		}

		public AwsTarget(string name, TargetType type, string resolvedName, TargetType resolvedType) : this(name, type) {
			_resolvedTarget = resolvedName == null ? "" : resolvedName;
			_resolvedTargetType = resolvedType;
		}

		public AwsTarget(string name, TargetType type, bool isPrimary, int escalationLevel, string resolvedName,
		                 TargetType resolvedType) : this(name, type, resolvedName, resolvedType) {
			_isPrimary = isPrimary;
			_escalationLevel = escalationLevel;
		}

		public static TargetType ParseTargetType(string val) {
			try {
				return (TargetType) Enum.Parse(typeof (TargetType), val.Trim(), true);
			}
			catch (ArgumentException ex) {
				return TargetType.None;
			}
		}

		public override string ToString() {
			return
				string.Format(
					"Target: {0}, Type: {1}, IsPrimary: {2}, EscalationLevel: {3}, ResolvedTarget: {4}, ResolvedType: {5}", _name,
					_type, _isPrimary, _escalationLevel, _resolvedTarget, _resolvedTargetType);
		}

		public void Deserialize(XmlNode targetNode) {
			XmlAttributeCollection attrs = targetNode.Attributes;
			_name = AwsXmlUtils.GetStringAttributeValue(attrs, "name");
			_type = ParseTargetType(AwsXmlUtils.GetStringAttributeValue(attrs, "type"));
			_isPrimary = AwsXmlUtils.GetBooleanFromIntegerAttributeValue(attrs, "isPrimary");
			_escalationLevel = AwsXmlUtils.GetIntegerAttributeValue(attrs, "escalationLevel");
			_resolvedTarget = AwsXmlUtils.GetStringAttributeValue(attrs, "resolvedTarget");
			_resolvedTargetType = ParseTargetType(AwsXmlUtils.GetStringAttributeValue(attrs, "resolvedTargetType"));
		}

		public void Serialize(XmlTextWriter w) {
			w.WriteStartElement("target");
			w.WriteAttributeString("name", _name);
			w.WriteAttributeString("type", _type.ToString());
			w.WriteAttributeString("isPrimary", _isPrimary ? "1" : "0");
			w.WriteAttributeString("escalationLevel", _escalationLevel.ToString());
			w.WriteAttributeString("resolvedTarget", _resolvedTarget);
			w.WriteAttributeString("resolvedTargetType", _resolvedTargetType.ToString());
			w.WriteEndElement();
		}

		public static AwsTarget LoadAwsTargetConfigurationFromDataReader(IDataReader reader) {
			return
				new AwsTarget(GetString(reader["TaskTargetName"]), ParseTargetType(GetString(reader["TaskTargetType"])),
				              GetBooleanValueFromNumber(reader["IsPrimary"]), GetInt32(reader["EscalationLevel"]), "",
				              ParseTargetType(""));
		}

		#region Helper functions for Mapper

		public static int GetInt32(object obj) {
			if (obj is DBNull)
				return 0;
			else
				return Convert.ToInt32(obj);
		}

		public static string GetString(object obj) {
			if (obj is DBNull)
				return "";
			else
				return obj.ToString();
		}

		public static bool GetBooleanValueFromNumber(object obj) {
			int number = GetInt32(obj);
			if (number == 1)
				return true;
			else
				return false;
		}

		#endregion
	}

	public enum TargetType {
		None,
		User,
		Group,
		Team,
		App,
		Dynamic,
		XslRule,
		ScriptRule,
		WebService
	}
}