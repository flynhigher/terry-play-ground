using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Xml;

namespace AllianceCapital.Aws.Api {
	/// <summary>
	/// Summary description for AwsTargetList.
	/// </summary>
	[Serializable]
	public class AwsTargetList : CollectionBase {
		public AwsTarget PrimaryTarget {
			get {
				foreach (AwsTarget t in List) {
					if (t.IsPrimary)
						return t;
				}
				return this[List.Add(new AwsTarget("", TargetType.None, true, 0))];
			}
			set {
				value.IsPrimary = true;
				value.EscalationLevel = 0;
				int index = -1;
				for (int i = 0; i < List.Count; i++) {
					AwsTarget t = List[i] as AwsTarget;
					if (t.IsPrimary)
						index = i;
				}
				if (index >= 0)
					List[index] = value;
				else
					List.Add(value);
			}
		}

		/// <summary>
		/// Add a target. If item being added is primary target it will overwrite existing primary target. If item exists already exception will be thrown.
		/// </summary>
		/// <param name="item"></param>
		/// <returns></returns>
		public int Add(AwsTarget item) {
			if (item == null)
				throw new ArgumentNullException("item");
			if (item.IsPrimary) {
				PrimaryTarget = item;
				for (int i = 0; i < List.Count; i++) {
					AwsTarget t = List[i] as AwsTarget;
					if (t.IsPrimary) return i;
				}
				return 0;
			}

			if (Contains(item))
				throw new ArgumentException("Aws target already exists.");

			return List.Add(item);
		}

		/// <summary>
		/// Remove target. You cannot remove primary target. Instead, you can replace it via 'PrimaryTarget' set property
		/// </summary>
		/// <param name="item"></param>
		public void Remove(AwsTarget item) {
			int indexOf = IndexOf(item);
			if (indexOf >= 0 && this[indexOf].IsPrimary)
				throw new ArgumentException(
					"Primary Target cannot be removed. Instead, you can replace it via 'PrimaryTarget' set property");
			List.Remove(item);
		}

		public bool Contains(AwsTarget item) {
			if (IndexOf(item) >= 0)
				return true;
			return false;
		}

		public int IndexOf(AwsTarget item) {
			return
				IndexOf(item.Name, item.Type, item.IsPrimary, item.EscalationLevel, item.ResolvedTarget, item.ResolvedTargetType);
		}

		public int IndexOf(string name, TargetType type, bool isPrimary, int escalationLevel, string resolvedTarget,
		                   TargetType resolvedTargetType) {
			for (int i = 0; i < List.Count; i++) {
				AwsTarget t = List[i] as AwsTarget;
				if (t.Name == name
				    && t.Type == type
				    && t.IsPrimary == isPrimary
				    && t.ResolvedTarget == resolvedTarget
				    && t.ResolvedTargetType == resolvedTargetType
				    && t.EscalationLevel == escalationLevel)
					return i;
			}
			return -1;
		}

		public void CopyTo(AwsTarget[] array, int index) {
			List.CopyTo(array, index);
		}

		public AwsTarget this[int index] {
			get { return (AwsTarget) List[index]; }
			set {
				if (value.IsPrimary && !((AwsTarget) List[index]).IsPrimary)
					throw new ArgumentException("You can not replace non-primary target with primary target.");
				if (!value.IsPrimary && ((AwsTarget) List[index]).IsPrimary)
					throw new ArgumentException("You can not replace primary target with non-primary target.");

				List[index] = value;
			}
		}

		public string GetXmlString() {
			StringBuilder sb = new StringBuilder();
			using (StringWriter writer = new StringWriter(sb)) {
				XmlTextWriter xmlWriter = new XmlTextWriter(writer);
				Serialize(xmlWriter);
			}
			return sb.ToString();
		}

		public void Serialize(XmlTextWriter w) {
			w.WriteStartElement("targets");
			foreach (AwsTarget target in List)
				target.Serialize(w);
			w.WriteEndElement();
		}

		public void Deserialze(XmlNode targetsNode) {
			if (targetsNode != null) {
				XmlNodeList targetNodes = targetsNode.SelectNodes("target");
				if (targetNodes.Count == 1)
					DeserializePrimaryTarget(targetNodes[0]);
				else {
					foreach (XmlNode targetNode in targetNodes)
						DeserializeTarget(targetNode);
				}
			}
		}

		private void DeserializeTarget(XmlNode targetNode) {
			AwsTarget target = new AwsTarget();
			target.Deserialize(targetNode);
			Add(target);
		}

		private void DeserializePrimaryTarget(XmlNode targetNode) {
			AwsTarget target = new AwsTarget();
			target.Deserialize(targetNode);
			target.IsPrimary = true;
			Add(target);
		}
	}
}