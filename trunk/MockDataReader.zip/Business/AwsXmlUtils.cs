using System;
using System.Xml;

namespace AllianceCapital.Aws.Api {
	/// <summary>
	/// Summary description for AwsXmlUtils.
	/// </summary>
	public class AwsXmlUtils {
		public static string GetValue(XmlNode xmlnode, string xpath, bool isMandatory) {
			if (null == xmlnode) {
				string message = @"XML node is null.";
				throw new AwsApiException(message);
			}

			XmlNode theNode = xmlnode.SelectSingleNode(xpath);
			string theValue = "";

			if (theNode == null) {
				if (isMandatory.Equals(false)) {
					return theValue;
				}
				else {
					string message = @"Missing mandatory field or attribute [" + xpath + @"] in XML node [" + xmlnode.OuterXml + @"].";
					throw new AwsApiException(message);
				}
			}
			else {
				return GetInnerTextOrInnerXml(theNode);
			}
		}

		public static string GetValue(XmlNode xmlNode, string xpath) {
			bool isMandatory = false;
			return GetValue(xmlNode, xpath, isMandatory);
		}

		public static string GetValue(XmlNode xmlNode, bool isMandatory) {
			return GetValue(xmlNode, ".", isMandatory);
		}

		public static string GetValue(XmlNode xmlNode) {
			bool isMandatory = false;
			return GetValue(xmlNode, ".", isMandatory);
		}

		public static string GetValue(XmlDocument xmldoc, string xpath, bool isMandatory) {
			if (null == xmldoc) {
				string message = @"XML doc is null.";
				throw new AwsApiException(message);
			}

			XmlNode theNode = xmldoc.SelectSingleNode(xpath);
			string theValue = "";

			if (theNode == null) {
				if (isMandatory.Equals(false)) {
					return theValue;
				}
				else {
					string message = @"Missing mandatory field or attribute [" + xpath + @"] in XML document [" + xmldoc.OuterXml +
					                 @"].";
					throw new AwsApiException(message);
				}
			}
			else {
				return GetInnerTextOrInnerXml(theNode);
			}
		}


		public static string GetInnerTextOrInnerXml(XmlNode xmlnode) {
			string retVal = xmlnode.InnerXml;

			if (retVal.StartsWith("<![CDATA[")) {
				retVal = xmlnode.InnerText;
			}
			return retVal;
		}

		public static string GetStringAttributeValue(XmlAttributeCollection attrs, string attrName) {
			XmlNode node = attrs.GetNamedItem(attrName);
			if (node != null)
				return node.Value;
			return "";
		}

		public static bool GetBooleanAttributeValue(XmlAttributeCollection attrs, string attrName) {
			XmlNode node = attrs.GetNamedItem(attrName);
			if (node != null)
				return Convert.ToBoolean(node.Value);
			return false;
		}

		public static int GetIntegerAttributeValue(XmlAttributeCollection attrs, string attrName) {
			XmlNode node = attrs.GetNamedItem(attrName);
			if (node != null)
				return Convert.ToInt32(node.Value);
			return 0;
		}

		public static bool GetBooleanFromIntegerAttributeValue(XmlAttributeCollection attrs, string attrName) {
			XmlNode node = attrs.GetNamedItem(attrName);
			if (node != null && node.Value.Length > 0)
				return Convert.ToInt32(node.Value) == 1 ? true : false;
			return false;
		}

		public static XmlDocument WrapXmlStringIntoXmlDocument(string xmlString) {
			if (xmlString == null || xmlString.Length == 0)
				throw new ArgumentException("Invalid or empty xml element string.", "xmlString");
			XmlDocument returnDoc = new XmlDocument();
			returnDoc.LoadXml(xmlString);
			return returnDoc;
		}
	}
}