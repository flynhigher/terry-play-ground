using System;
using System.Data;
using AllianceCapital.Aws.Api;
using AllianceCapital.Aws.AwsException;
using AllianceCapital.Wsg.Data;

namespace AllianceCapital.Aws.ServerDataAccess {
	/// <summary>
	/// Summary description for ServerDataAccess.
	/// </summary>
	[Serializable]
	public class AwsServerDataAccess {
		public virtual string GetOrchestration(string applicationName, string processName) {
			const string proc = "uspGetOrchestration";
			string strError =
				String.Format("Failed to retrieve orchestration ID for {0}.{1} - proc: {2}", applicationName, processName, proc);
			try {
				Database db = DbServiceFactory.CreateDatabaseService("AWS");
				IDbCommandWriter cw = db.CreateDbCommandWriter(proc, CommandType.StoredProcedure);
				cw.AddInParam("@application", DbType.String, applicationName);
				cw.AddInParam("@process", DbType.String, processName);
				cw.AddOutParam("@orchestration", DbType.String, 50);
				cw.AddParam("RETVAL", DbType.Int32, ParameterDirection.ReturnValue, "", DataRowVersion.Current, 0);

				db.ExecuteNonQuery(cw);
				int returnValue = (int) cw.GetParamValue("RETVAL");
				if (returnValue < 0) //Error checking routine
					throw new Exception("Error: code " + returnValue.ToString());
				string orchestrationName = cw.GetParamValue("@orchestration").ToString();
				if (orchestrationName != null)
					return orchestrationName;
			}
			catch (Exception e) {
				AwsServerException e1 = new AwsServerException(strError, e);
				throw(e1);
			}
			return "";
		}

		public virtual TaskInformation GetTaskInformationByAppNameProcessNameOrchestrationTaskName(string applicationName,
		                                                                                           string processName,
		                                                                                           string
		                                                                                           	orchestrationTaskName) {
			string proc =
				String.Format(
					"select * from vAppBProcessTasks where ApplicationName = '{0}' and BProcessName = '{1}' and OrchestrationTaskName = '{2}'",
					applicationName, processName, orchestrationTaskName);
			try {
				Database db = DbServiceFactory.CreateDatabaseService("AWS");
				IDbCommandWriter cw = db.CreateDbCommandWriter(proc, CommandType.Text);
				cw.AddParam("RETVAL", DbType.Int32, ParameterDirection.ReturnValue, "", DataRowVersion.Current, 0);

				using (IDataReader reader = db.ExecuteReader(cw)) {
					int returnValue = (int) cw.GetParamValue("RETVAL");
					if (returnValue < 0) //Error checking routine
						throw new Exception("Error: code " + returnValue.ToString());

					if (reader.Read()) {
						TaskInformation taskInfo = TaskInformation.LoadTaskInformationFromDataReader(reader);
						taskInfo.TargetList = GetTargetListByTaskConfigurationGuid(reader["TaskConfigurationGuid"].ToString());
						return taskInfo;
					}
					else
						throw new AwsServerException("No orchestration task configuration information loaded.");
				}
			}
			catch (Exception e) {
				string strError = "DB Call: " + proc;
				AwsServerException e1 = new AwsServerException(strError, e);
				throw(e1);
			}
		}

		private AwsTargetList GetTargetListByTaskConfigurationGuid(string taskConfigurationGuid) {
			string proc = string.Format("select * from TaskTarget where TaskConfigurationGuid = '{0}'", taskConfigurationGuid);
			AwsTargetList targetList = new AwsTargetList();
			try {
				Database db = DbServiceFactory.CreateDatabaseService("AWS");
				IDbCommandWriter cw = db.CreateDbCommandWriter(proc, CommandType.Text);
				cw.AddParam("RETVAL", DbType.Int32, ParameterDirection.ReturnValue, "", DataRowVersion.Current, 0);

				using (IDataReader reader = db.ExecuteReader(cw)) {
					int returnValue = (int) cw.GetParamValue("RETVAL");
					if (returnValue < 0) //Error checking routine
						throw new Exception("Error: code " + returnValue.ToString());

					while (reader.Read()) {
						targetList.Add(AwsTarget.LoadAwsTargetConfigurationFromDataReader(reader));
					}
				}
			}
			catch (Exception e) {
				string strError = "DB Call: " + proc;
				AwsServerException e1 = new AwsServerException(strError, e);
				throw(e1);
			}
			return targetList;
		}

		public virtual TaskInformation GetTaskInformationByAppNameProcessNameTaskName(string applicationName,
		                                                                              string processName, string taskName) {
			string proc =
				String.Format(
					"select * from vAppBProcessTasks where ApplicationName = '{0}' and BProcessName = '{1}' and TaskName = '{2}'",
					applicationName, processName, taskName);
			try {
				Database db = DbServiceFactory.CreateDatabaseService("AWS");
				IDbCommandWriter cw = db.CreateDbCommandWriter(proc, CommandType.Text);
				cw.AddParam("RETVAL", DbType.Int32, ParameterDirection.ReturnValue, "", DataRowVersion.Current, 0);

				using (IDataReader reader = db.ExecuteReader(cw)) {
					int returnValue = (int) cw.GetParamValue("RETVAL");
					if (returnValue < 0) //Error checking routine
						throw new Exception("Error: code " + returnValue.ToString());

					if (reader.Read()) {
						TaskInformation taskInfo = TaskInformation.LoadTaskInformationFromDataReader(reader);
						taskInfo.TargetList = GetTargetListByTaskConfigurationGuid(reader["TaskConfigurationGuid"].ToString());
						return taskInfo;
					}
					else
						throw new AwsServerException("No task configuration information loaded.");
				}
			}
			catch (Exception e) {
				string strError = "DB Call: " + proc;
				AwsServerException e1 = new AwsServerException(strError, e);
				throw(e1);
			}
		}

		public virtual BProcessInformation GetBProcessInformationByAppNameProcessName(string applicationName,
		                                                                              string processName) {
			string proc =
				String.Format("SELECT * FROM vApplicationProcesses WHERE ApplicationName = '{0}' AND BProcessName = '{1}'",
				              applicationName, processName);
			try {
				Database db = DbServiceFactory.CreateDatabaseService("AWS");
				IDbCommandWriter cw = db.CreateDbCommandWriter(proc, CommandType.Text);
				cw.AddParam("RETVAL", DbType.Int32, ParameterDirection.ReturnValue, "", DataRowVersion.Current, 0);

				using (IDataReader reader = db.ExecuteReader(cw)) {
					int returnValue = (int) cw.GetParamValue("RETVAL");
					if (returnValue < 0) //Error checking routine
						throw new Exception("Error: code " + returnValue.ToString());

					if (reader.Read())
						return BProcessInformation.LoadBProcessInformationFromDataReader(reader);
					else
						throw new AwsServerException("No business process information loaded.");
				}
			}
			catch (Exception e) {
				string strError = "DB Call: " + proc;
				AwsServerException e1 = new AwsServerException(strError, e);
				throw(e1);
			}
		}

		public virtual void ProcessTaskRequest(string xml) {
			PostXmlDocument(xml, "uspInsertTaskRequest", "Failed to insert TaskRequest");
		}

		private void PostXmlDocument(string strXmlDoc, string proc, string strError) {
			try {
				Database db = DbServiceFactory.CreateDatabaseService("AWS");
				IDbCommandWriter cw = db.CreateDbCommandWriter(proc, CommandType.StoredProcedure);
				cw.AddInParam("@xmlDocument", DbType.String, strXmlDoc);
				cw.AddParam("RETVAL", DbType.Int32, ParameterDirection.ReturnValue, "", DataRowVersion.Current, 0);

				db.ExecuteNonQuery(cw);
				int returnValue = (int) cw.GetParamValue("RETVAL");
				//Error checking routine
				if (returnValue < 0) {
					strError = "Error: code " + returnValue.ToString();
					AwsServerException e1 = new AwsServerException(strError);
					//					e1.Publish(AwsLogCategory.AwsServerError);
					throw(e1);
				}
			}
			catch (Exception e) {
				strError = string.Format("DB Call: {0}({1})", proc, strXmlDoc);
				AwsServerException e1 = new AwsServerException(strError, e);
				throw(e1);
			}
		}

		#region Helper functions for Mapper

		public static int GetInt32(object obj) {
			if (obj is DBNull)
				return 0;
			else
				return Convert.ToInt32(obj);
		}

		public static string GetString(object obj) {
			if (obj is DBNull)
				return "";
			else
				return obj.ToString();
		}

		public static Guid GetGuid(string guidString) {
			if (guidString == null || guidString.Length == 0)
				return Guid.Empty;
			else
				return new Guid(guidString);
		}

		public static bool GetBooleanValueFromNumber(object obj) {
			int number = GetInt32(obj);
			if (number == 1)
				return true;
			else
				return false;
		}

		#endregion
	}
}