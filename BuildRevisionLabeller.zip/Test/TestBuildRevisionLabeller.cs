using NUnit.Framework;
using ThoughtWorks.CruiseControl.Remote;

namespace BuildRevisionLabeller.Test
{
	[TestFixture()]
	public class TestBuildRevisionLabeller 
	{
		private BuildRevisionLabeller _unitUnderTest;
		ThoughtWorks.CruiseControl.Core.IIntegrationResult _result = null;
		
		[SetUp()]
		public void SetUp() 
		{
			_unitUnderTest = new BuildRevisionLabeller();
			_result = new MockIIntegrationResult();
			_result.Label = "version-1.1.3.4-builder";
			_result.Status = IntegrationStatus.Success;
		}

		[TearDown()]
		public void TearDown() 
		{
			_unitUnderTest = null;
			_result = null;
		}

		[Test]
		public void TestRun()
		{
			_unitUnderTest.Run(_result);
			Assert.AreEqual("1.1.4.4", _result.Label);
		}

		[Test]
		public void TestRunWithResetRevision()
		{
			_unitUnderTest.ResetRevision = true;
			_unitUnderTest.Run(_result);
			Assert.AreEqual("1.1.4.0", _result.Label);
		}
	
		[Test]
		public void TestInitialRun()
		{
			_result.Label = null;
			_unitUnderTest.Run(_result);
			Assert.AreEqual("0.0.1.0", _result.Label);
		}
	
		[Test]
		public void TestBuildAndRevisionRun()
		{
			_unitUnderTest.IncrementRevision = true;
			_unitUnderTest.Run(_result);
			Assert.AreEqual("1.1.4.5", _result.Label);
		}
	
		[Test]
		public void TestOnlyRevisionRun()
		{
			_unitUnderTest.IncrementBuild = false;
			_unitUnderTest.IncrementRevision = true;
			_unitUnderTest.Run(_result);
			Assert.AreEqual("1.1.3.5", _result.Label);
		}
	
		[Test]
		public void TestLastResultFailureRun()
		{
			_result.Status = IntegrationStatus.Failure;
			_unitUnderTest.Run(_result);
			Assert.AreEqual("version-1.1.3.4-builder", _result.Label);
		}
	
		[Test]
		public void TestLastResultUnknownRun()
		{
			_result.Label = null;
			_result.Status = IntegrationStatus.Unknown;
			_unitUnderTest.Run(_result);
			Assert.AreEqual("0.0.1.0", _result.Label);
		}
	
		[Test]
		public void TestBuildAndRevisionRunWithPrefixAndPostfix()
		{
			_unitUnderTest.IncrementRevision = true;
			_unitUnderTest.LabelPrefix = "v";
			_unitUnderTest.LabelPostfix = "-ttt";
			_unitUnderTest.Run(_result);
			Assert.AreEqual("v1.1.4.5-ttt", _result.Label);
		}

		[Test]
		public void TestRunWithPlainFile()
		{
			_unitUnderTest.VersionFilePath = "version.txt";
			_unitUnderTest.Run(_result);
			Assert.AreEqual("1.1.61.2", _result.Label);
		}
	
		[Test]
		public void TestLastResultUnknownRunWithPlainFile()
		{
			_result.Label = null;
			_result.Status = IntegrationStatus.Unknown;
			_unitUnderTest.VersionFilePath = "version.txt";
			_unitUnderTest.Run(_result);
			Assert.AreEqual("1.1.61.2", _result.Label);
		}

		[Test]
		public void TestRunWithXmlFile()
		{
			_unitUnderTest.VersionFilePath = "version.xml";
			_unitUnderTest.VersionXPath = "//version";
			_unitUnderTest.Run(_result);
			Assert.AreEqual("1.1.61.2", _result.Label);
		}

		[Test]
		public void TestRunWithXmlFileAndAttribute()
		{
			_unitUnderTest.VersionFilePath = "version.xml";
			_unitUnderTest.VersionXPath = "//version/@value";
			_unitUnderTest.Run(_result);
			Assert.AreEqual("1.1.61.2", _result.Label);
		}
	}
}