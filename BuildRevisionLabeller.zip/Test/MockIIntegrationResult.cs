using System;
using System.Collections;
using ThoughtWorks.CruiseControl.Core;
using ThoughtWorks.CruiseControl.Remote;

namespace BuildRevisionLabeller.Test
{
	/// <summary>
	/// Summary description for MockIIntegrationResult.
	/// </summary>
	public class MockIIntegrationResult : IIntegrationResult
	{
		private string _label;
		private IntegrationStatus _status;

		public MockIIntegrationResult()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ThoughtWorks.CruiseControl.Remote.IntegrationStatus LastIntegrationStatus {
			get { throw new NotImplementedException(); }
		}

		public ThoughtWorks.CruiseControl.Remote.IntegrationStatus Status {
			get { return _status; }
			set { _status = value; }
		}

		public ThoughtWorks.CruiseControl.Remote.BuildCondition BuildCondition {
			get { throw new NotImplementedException(); }
		}

		public void AddTaskResult(string result) {
			throw new NotImplementedException();
		}

		public void AddTaskResult(ITaskResult result) {
			throw new NotImplementedException();
		}

		public bool IsInitial() {
			return false;
		}

		public bool HasModifications() {
			throw new NotImplementedException();
		}

		public void MarkStartTime() {
			throw new NotImplementedException();
		}

		public void MarkEndTime() {
			throw new NotImplementedException();
		}

		public bool ShouldRunBuild() {
			throw new NotImplementedException();
		}

		public string BaseFromArtifactsDirectory(string pathToBase) {
			throw new NotImplementedException();
		}

		public string BaseFromWorkingDirectory(string pathToBase) {
			throw new NotImplementedException();
		}

		public string ProjectName {
			get { throw new NotImplementedException(); }
		}

		public string WorkingDirectory {
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

		public string Label {
			get { return _label; }
			set { _label = value; }
		}

		public string LastSuccessfulIntegrationLabel {
			get { throw new NotImplementedException(); }
		}

		public DateTime StartTime {
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

		public DateTime EndTime {
			get { throw new NotImplementedException(); }
		}

		public TimeSpan TotalIntegrationTime {
			get { throw new NotImplementedException(); }
		}

		public IList TaskResults {
			get { throw new NotImplementedException(); }
		}

		public DateTime LastModificationDate {
			get { throw new NotImplementedException(); }
		}

		public int LastChangeNumber {
			get { throw new NotImplementedException(); }
		}

		public Modification[] Modifications {
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

		public Exception ExceptionResult {
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

		public string ArtifactDirectory {
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

		public string ProjectUrl {
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

		public string TaskOutput {
			get { throw new NotImplementedException(); }
		}

		public bool Failed {
			get { throw new NotImplementedException(); }
		}

		public bool Fixed {
			get { throw new NotImplementedException(); }
		}

		public bool Succeeded {
			get { throw new NotImplementedException(); }
		}

		public IDictionary IntegrationProperties {
			get { throw new NotImplementedException(); }
		}
	}
}
