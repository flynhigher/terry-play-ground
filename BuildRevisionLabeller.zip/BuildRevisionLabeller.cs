using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using Exortech.NetReflector;
using ThoughtWorks.CruiseControl.Core;
using ThoughtWorks.CruiseControl.Remote;

namespace BuildRevisionLabeller
{
	/// <summary>
	/// Summary description for BuildRevisionLabeller.
	/// </summary>
	[ReflectorType("buildRevisionLabeller")]
	public class BuildRevisionLabeller : ILabeller, ITask
	{
		public static readonly string INITIAL_VERSION = "0.0.1.0";

		[ReflectorProperty("incrementOnFailure", Required=false)]
		public bool IncrementOnFailure;
		[ReflectorProperty("incrementBuild", Required=false)]
		public bool IncrementBuild = true;
		[ReflectorProperty("incrementRevision", Required=false)]
		public bool IncrementRevision;
		[ReflectorProperty("resetRevision", Required=false)]
		public bool ResetRevision;
		[ReflectorProperty("prefix", Required=false)]
		public string LabelPrefix = "";
		[ReflectorProperty("postfix", Required=false)]
		public string LabelPostfix = "";
		[ReflectorProperty("versionFilePath", Required=false)]
		public string VersionFilePath = "";
		[ReflectorProperty("versionXPath", Required=false)]
		public string VersionXPath = "";

		public void Run(IIntegrationResult result) 
		{
			result.Label = Generate(result);
		}

		public string Generate(IIntegrationResult resultFromLastBuild) 
		{
			if(ShouldChangeLabel(resultFromLastBuild)) 
				return LabelPrefix + IncrementVersion(resultFromLastBuild) + LabelPostfix;
			else
				return resultFromLastBuild.Label;
		}

		#region Helper

		private string IncrementVersion(IIntegrationResult resultFromLastBuild) {
			if (IsThisFirstBuild(resultFromLastBuild) && !ShouldGetVersionFromFile())
				return INITIAL_VERSION;
			else {
				Version version = new Version(GetOldVersionString(resultFromLastBuild));
				version = new Version(version.Major, version.Minor, GetNewBuild(version.Build), GetNewRevision(version.Revision));
				return version.ToString();
			}
		}

		private bool ShouldGetVersionFromFile() {
			return (VersionFilePath != null && VersionFilePath.Length > 0);
		}

		private bool IsThisFirstBuild(IIntegrationResult resultFromLastBuild) {
			return (resultFromLastBuild == null || resultFromLastBuild.IsInitial()
			        || resultFromLastBuild.Label == null || resultFromLastBuild.Label.Length == 0);
		}

		private int GetNewBuild(int build) {
			return IncrementBuild ? build + 1 : build;
		}

		private int GetNewRevision(int revision) {
			if(IncrementBuild && ResetRevision)
				return 0;
			else
				return IncrementRevision ? revision + 1 : revision;
		}

		private string GetOldVersionString(IIntegrationResult resultFromLastBuild) {
			if(ShouldGetVersionFromFile()) 
				return GetVersionStringFromFile();
			else {
				Match match = Regex.Match(resultFromLastBuild.Label, @"[\d]+\.[\d]+\.[\d]+\.[\d]+");
				return match.ToString();
			}
		}

		private string GetVersionStringFromFile() {
			using(StreamReader reader = new StreamReader(VersionFilePath)) {
				if(VersionXPath.Length > 0) {
					XmlDocument xmldoc = new XmlDocument();
					xmldoc.Load(reader);
					XmlNode node = xmldoc.SelectSingleNode(VersionXPath);
					return node.InnerText;
				}
				else
					return reader.ReadLine();
			}
		}
		
		private bool ShouldChangeLabel(IIntegrationResult previousResult)
		{
			if (previousResult.Status != IntegrationStatus.Success
				&& previousResult.Status != IntegrationStatus.Unknown)
				return IncrementOnFailure;
			else
				return true;
		}

		#endregion
	}
}
